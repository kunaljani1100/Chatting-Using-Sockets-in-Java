package kunal;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	try
    {
        ServerSocket serverSocket=new ServerSocket(2500);
        System.out.println("Waiting for the client to connect to the server.");
        Socket socket=serverSocket.accept();
        Scanner scanner=new Scanner(System.in);
        System.out.println("The client has connected to the chatting application.");
        BufferedReader taketxt=new BufferedReader(new InputStreamReader(socket.getInputStream()));
        PrintWriter sendtxt=new PrintWriter(socket.getOutputStream(),true);
        String msg="";
        String recievedmsg;
        System.out.println("Chatting application has started. Type \"exit\" if you want to leave");
        while(!msg.equals("exit"))
        {
            System.out.println("You:");
            msg=scanner.nextLine();
            if(msg.equals("exit"))
                break;
            sendtxt.println("Server:"+msg);
            recievedmsg=taketxt.readLine();
            if(recievedmsg.equals("exit"))
                break;
            System.out.println(recievedmsg);
        }
    }
    catch(SocketException e)
    {
        System.out.println("Client had disconnected.");
    }
    catch (IOException e)
    {
        System.out.println("Input error.");
    }
    }
}
