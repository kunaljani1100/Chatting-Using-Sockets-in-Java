package kunal;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

/**
 * Created by kunal on 21-07-2017.
 */
public class Main {
    public static void main(String args[]){
        try
        {
            Socket socket=new Socket("localhost",2500);
            BufferedReader taketxt=new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter sendtxt=new PrintWriter(socket.getOutputStream(),true);
            Scanner scanner=new Scanner(System.in);
            System.out.println("You are connected to the server. You can now start chatting with the server." +
                    "Type \"exit\" if you want to leave.");
            String msg="";
            String recievedmsg;
            while(!msg.equals("exit"))
            {
                recievedmsg=taketxt.readLine();
                if(recievedmsg.equals("exit"))
                    break;
                System.out.println(recievedmsg);
                System.out.println("You:");
                msg=scanner.nextLine();
                if(msg.equals("exit"))
                    break;
                sendtxt.println("Client:"+msg);
            }
        }
        catch (IOException e)
        {
            System.out.println("Not connected to the server.");
        }
    }
}
